<html>
<head>
<style>
@media screen and (max-width: 80px) {
  .news {
    position:relative;margin-left:auto;margin-right:auto;margin-top:400px  ;
  }
  .text1{
  	box-shadow:none !important;
    position:relative;
      margin-left:auto;margin-right:auto;
  }
}
.blue {
    background: #a6ddef; /*news*/
}

.news {
    box-shadow: inset 0 -15px 30px rgba(101, 186, 235, 0.4), 0 5px 10px rgba(101, 186, 235, 0.4);
       width: 100%;
       height:50px;
    margin-top:0px;
    overflow: hidden;

    border-radius: 4px;
    padding: 1px;
    -webkit-user-select: none;

}


.key-facts {
    background-color: #aeed9a; /* Replace with your desired color */
}



.news span {
    float: left;
    color: #0d0101;
    padding: 9px;
    position: relative;
    top: 1%;
    box-shadow: inset 0 -15px 30px rgba(207, 32, 59, 0.4);
    font: 16px 'Raleway', Helvetica, Arial, sans-serif;
    -webkit-font-smoothing: antialiased;
    -webkit-user-select: none;
    cursor: pointer;
}

.text1{

	box-shadow:none !important;
  position:relative;
    width:90%
}
</style>
</head>
<body>
<div class="news blue">
<span class="key-facts" style="background-color:#e6c281;width:100px;height:50px">Key Facts</span><span class="text1" ><marquee>Right now, we need 15 million blood units yearly. However, the supply of blood from donors only provides 10 million blood units. <b>In order to close this gap, Come and Be a Part of this Noble Cause :) Lets Save Life </b> Conatact Us below. </marquee></span>
</div>
</body>
</head>
</html>
